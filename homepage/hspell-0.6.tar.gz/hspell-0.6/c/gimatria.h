#ifndef INCLUDED_GIMATRIA_H
#define INCLUDED_GIMATRIA_H

int is_canonic_gimatria(const char *w);

#endif /* INCLUDED_GIMATRIA_H */
